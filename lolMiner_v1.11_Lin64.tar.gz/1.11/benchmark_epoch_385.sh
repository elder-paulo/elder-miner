#!/bin/bash

./lolMiner --benchmark ETHASH --benchepoch 385 --keepfree 5 --longstats 120
